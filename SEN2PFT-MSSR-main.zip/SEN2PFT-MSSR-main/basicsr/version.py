# GENERATED VERSION FILE
# TIME: Tue Oct 14 22:56:02 2025
__version__ = '0.1.1'
__gitsha__ = ''
version_info = (0, 1, 1)
